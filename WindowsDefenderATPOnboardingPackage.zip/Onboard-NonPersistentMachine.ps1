﻿# Some organizations, use non-persistent virtual machines for their users
# A non-persistent machine is created from a master image
# Every new machine instance has a different name and these machines are available via pool
# Every user logon \ reboot returns machine to image state loosing all user data
# This script provides a solution for onboarding such machines
# We would like to have sense unique id per machine name in organization
# For that purpose, senseGuid is set prior to onboarding
# The guid is created deterministically based on combination of orgId and machine name 
# This script is intended to be integrated in golden image startup
Param (	
	[string]
	[ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path $_ -PathType ‘Container’})]
	$onboardingPackageLocation = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Path)
)

Add-Type @'
using System; 
using System.Diagnostics; 
using System.Diagnostics.Tracing; 
namespace Sense 
{ 
	[EventData(Name = "Onboard")]
	public struct Onboard
	{
		public string Message { get; set; }
	} 
	public class Trace 
	{
		public static EventSourceOptions TelemetryCriticalOption = new EventSourceOptions(){Level = EventLevel.Informational, Keywords = (EventKeywords)0x0000800000000000, Tags = (EventTags)0x0200000}; 
		public void WriteMessage(string message)
		{
			es.Write("OnboardNonPersistentMachine", TelemetryCriticalOption, new Onboard {Message = message});
		} 
		private static readonly string[] telemetryTraits = { "ETW_GROUP", "{5ECB0BAC-B930-47F5-A8A4-E8253529EDB7}" }; 
		private EventSource es = new EventSource("Microsoft.Windows.Sense.Client.VDI",EventSourceSettings.EtwSelfDescribingEventFormat,telemetryTraits);
	}
}
'@

$logger = New-Object -TypeName Sense.Trace;

function Trace([string] $message)
{
    $logger.WriteMessage($message)
}

function CreateGuidFromString([string]$str)
{
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($str)
    $sha1CryptoServiceProvider = New-Object System.Security.Cryptography.SHA1CryptoServiceProvider
    $hashedBytes = $sha1CryptoServiceProvider.ComputeHash($bytes)
    [System.Array]::Resize([ref]$hashedBytes, 16);
    return New-Object System.Guid -ArgumentList @(,$hashedBytes)
}

function GetComputerName 
{
    return [system.environment]::MachineName
}

function ReadOrgIdFromOnboardingScript($onboardingScript)
{
    return select-string -path $onboardingScript -pattern "orgId\\\\\\`":\\\\\\`"([^\\]+)" | %{ $_.Matches[0].Groups[1].Value }
}

function Test-Administrator  
{  
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    return (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)  
}

if ((Test-Administrator) -eq $false)
{
    Write-Host -ForegroundColor Red "The script should be executed with admin previliges"
    Trace("Script wasn't executed as admin");
    Exit 1;
}

Write-Host "Locating onboarding script under:" $onboardingPackageLocation

$onboardingScript = [System.IO.Path]::Combine($onboardingPackageLocation, "WindowsDefenderATPOnboardingScript.cmd");

if(![System.IO.File]::Exists($onboardingScript))
{
    Write-Host -ForegroundColor Red "Onboarding script not found:" $onboardingScript
    Trace("Default Onboarding script not found")
    $onboardingScript = [System.IO.Path]::Combine($onboardingPackageLocation, "DeviceComplianceOnboardingScript.cmd");
    if(![System.IO.File]::Exists($onboardingScript)) 
    {
        Write-Host -ForegroundColor Red "Onboarding script not found:" $onboardingScript
        Trace("Compliance Onboarding script not found")
        Exit 2;
    }
}

$orgId = ReadOrgIdFromOnboardingScript($onboardingScript);
if ([string]::IsNullOrEmpty($orgId))
{
    Write-Host -ForegroundColor Red "Could not deduct organization id from onboarding script:" $onboardingScript
    Trace("Could not deduct organization id from onboarding script")
    Exit 3;
}
Write-Host "Identified organization id:" $orgId

$computerName = GetComputerName;
Write-Host "Identified computer name:" $computerName

$id = $orgId + "_" + $computerName;
$senseGuid = CreateGuidFromString($id);
Write-Host "Generated senseGuid:" $senseGuid


$senseGuidRegPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Advanced Threat Protection"
$senseGuidValueName = "senseGuid";
$populatedSenseGuid = [Microsoft.Win32.Registry]::GetValue($senseGuidRegPath, $senseGuidValueName, $null)
$senseState = (Get-Service -Name "SENSE").Status
if ($populatedSenseGuid)
{
    Write-Host -ForegroundColor Red "SenseGuid already populated:" $populatedSenseGuid
    Trace("SenseGuid already populated. Attempting to clear SenseGuid if SENSE is stopped.")
    if ($senseState -eq "Stopped") 
    {
        [Microsoft.Win32.Registry]::SetValue($senseGuidRegPath, $senseGuidValueName, "")
    } else
    { 
        Write-Host -ForegroundColor Red "SENSE service state is:" $senseState
        Trace("Sense service is not stopped. Exiting script.")
        Exit 4;
    }
} 
[Microsoft.Win32.Registry]::SetValue($senseGuidRegPath, $senseGuidValueName, $senseGuid)
Write-Host "SenseGuid was set:" $senseGuid

$vdiTagRegPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging"
$vdiTagValueName = "VDI";
$vdiTag = "NonPersistent";
[Microsoft.Win32.Registry]::SetValue($vdiTagRegPath, $vdiTagValueName, $vdiTag)
Write-Host "VDI tag was set:" $vdiTag

Write-Host "Starting onboarding"
&$onboardingScript
if ($LASTEXITCODE -ne 0)
{
    Write-Host -ForegroundColor Red "Failed to onboard sense service from: $($onboardingScript). Exit code: $($LASTEXITCODE). To troubleshoot, please read https://technet.microsoft.com/en-us/itpro/windows/keep-secure/troubleshoot-onboarding-windows-defender-advanced-threat-protection"
    Trace("Failed to onboard sense service. LASTEXITCODE=" + $LASTEXITCODE)
    Exit 5;
}

Write-Host -ForegroundColor Green "Onboarding completed successfully"
Trace("SUCCESS")
# SIG # Begin signature block
# MIIntgYJKoZIhvcNAQcCoIInpzCCJ6MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYnzegT00/YN3V
# 5BLN+AdvSOEXCg7c3Cb/xp0eAzIdNKCCDZcwggYVMIID/aADAgECAhMzAAADEBr/
# fXDbjW9DAAAAAAMQMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwODA0MjAyNjM5WhcNMjMwODAzMjAyNjM5WjCBlDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjE+MDwGA1UEAxM1TWlj
# cm9zb2Z0IFdpbmRvd3MgRGVmZW5kZXIgQWR2YW5jZWQgVGhyZWF0IFByb3RlY3Rp
# b24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC0y67idUrLERDl3ls1
# 1XkmCQNGqDqXUbrM7xeQ3MDX2TI2X7/wxqqVBo5wjSGMUEUxZpgrQRj7fyyeQWvy
# OKx7cxcBYXxRWjOQRSYWqk+hcaLj7E9CkuYyM1tuVxuAehDD1jqwLGS5LfFG9iE9
# tXCQHI59kCLocKMNm2C8RWNNKlPYN0dkN/pcEIpf6L+P+GXYN76jL+k7uXY0Vgpu
# uKvUZdxukyqhYbWy8aNr8BasPSOudq2+1VzK52kbUq79M7F3lN+JfDdyiG5YoSdc
# XDrvOU1fnP1Kc4PtUJL7tSHFuBylTiNyDnHfSORQeZPFg971CeZS7I8ZFojDLgTY
# kDQDAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wv
# ATAdBgNVHQ4EFgQU0X7BWbJmeu82AxuDs7MBJC8zJ8swRQYDVR0RBD4wPKQ6MDgx
# HjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEWMBQGA1UEBRMNNDUxODk0
# KzQ3MjIyMDAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8E
# TTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBR
# BggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAw
# DQYJKoZIhvcNAQELBQADggIBAIXZp9/puv2exE6jflkfuJ3E8xrXA1ch9bnCloXS
# 01xOXTauGU/+1peumenJbgwCzn/iwGIJkuoHSx5F85n7OG9InPRApTNcYmAkGPIk
# /x5SNl67Su8eHlLGd8erjoEcseZBckRENr5mBHtELtOWR80cAH9dbALlY/gJ5FDq
# jOxA9Q6UDeaT9oeIJwSy/LD9sUKrUZ4zSvqFBjjEBx3g2TfmRe3qLfKJEOL1mzCk
# 06RHYwcU2uU1s5USCeePuafeQ159io+FVdW5f7703UeD4pzXOp4eZTtWl0875By+
# bWxAR8/dc41v2MEQoy0WplbGfkBm9BWT0w0pL3itBYcXRlzIfPForBPK2aIQOMPL
# CH8JR3uJXvbTJ5apXBAFOWl6dU1JqGTT/iuWsVznHBqDmq6zKf38QYocac0o7qL3
# RG1/eiQdbPQisNpFiqTzTd6lyUaXrPtk+BniKT4bVXJ2FrfsmLiXIcFhC6FAidok
# spWZVHS8T4WwSPVpmhjEgubZlhldva/wOT/OjtGzoy6L7yNKjcSadVou4VroLLK9
# qwYgKnjyzX8KEcGkKUXScwZIp8uWDp5bmKYh+5SQEa26bzHcX0a1iqmsUoP5JhYL
# xwloQM2AgY9AEAIHSFXfCo17ae/cxV3sEaLfuL09Z1sSQC5wm32hV3YyyEgsRDXE
# zXRCMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4
# MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3Y
# bqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUB
# FDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnbo
# MlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT
# +OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuy
# e4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEh
# NSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2
# z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3
# s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78Ic
# V9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E
# 11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5P
# M4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcV
# AQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBL
# hklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggr
# BgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsG
# AQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDB
# ZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc
# 8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYq
# wooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu
# 5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWI
# UUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXh
# j38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yH
# PgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtI
# EJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4Guzq
# N5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgR
# MiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQ
# zTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEC
# EzMAAAMQGv99cNuNb0MAAAAAAxAwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEILSuB3SU6AlZ/5YoYnfTQhvtAgb9pF9u1RMC/ynsg5oF
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAYgpBxik2p9PD
# 0PD4PCXTJufihh+2a+xdzJgpH+fGIpjZS3wZKTl6ZUKrk6qx3iadcMsrN0aos7l2
# cdU02MNzP0CujGbaV1GkYsBjR5aVsJY4HwFy9gpt3B6NcaZz5N+oHv/Vrv2KMnoK
# fcov28SbIKvkbpNtgg4KteWbdUm0tz6tWWJNVGNEQhyo3bHH+hDSC0F1AJl+S0eV
# VzMSwLi/N/9VOXtByY7wmo5YLrHKvxZ9mfAW3k5mSmVN808gb7ZW6vPBr3GCLNhw
# H+nfVVrzlPfd1Bfwp1SRheT8QQ9lOLO+O01P8JaS/LuDIC3QsDB6EYe6EiEwBgmj
# C4GlXLHCk6GCFv8wghb7BgorBgEEAYI3AwMBMYIW6zCCFucGCSqGSIb3DQEHAqCC
# FtgwghbUAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFQBgsqhkiG9w0BCRABBKCCAT8E
# ggE7MIIBNwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCBABHtiTvMj
# MDNY+5QeVqi4MLprkIsAtd9cGqd32gZkUwIGZItiVZVtGBIyMDIzMDYyMTA2NDY1
# Mi41M1owBIACAfSggdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ5QkMtRTM3QS0yMzNDMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIRVzCCBwwwggT0oAMCAQIC
# EzMAAAHAVaSNw2QVxUsAAQAAAcAwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkwMTI1WhcNMjQwMjAyMTkwMTI1
# WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UE
# CxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVz
# IFRTUyBFU046NDlCQy1FMzdBLTIzM0MxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC8
# 7WD7Y2GGYFC+UaUJM4xoXDeNsiFR0NOqRpCFGl0dVv6G5T/Qc2EuahFi+unvPm8i
# gvUw8CRUEVYkiStwbuxKt52fJnCt5jbTsL2fxeK8v1kE5B6JR4v9MyUnpWKetxp9
# uF2eQ07kkOU+jML10bJKK5uvJ2zkYq27r0PXA1q30MhCXpqUU7qmdxkrhEjN+/4r
# OQztGRje8emFXQLwQVSkX6XKxoYlcV/1CxRQfCP1cpYd9z0F+EugJF5dTO+Cuyl0
# WZWcD0BNheaJ1KOuyF/wD4TT8WlN2Fc8j1deqxkMcGqvsOVihIJTeW+tUNG7Wnmk
# cd/uzeQzXoekrpqsO1jdqLWygBKYSm/cLY3/LkwMECkN3hKlKQsxrv7p6z91p5Lv
# N0fWp0JrZGgk8zoSH/piYF+h+F8tCh8o8mXfgAuVlYrkDNW0VE05dpyiPowAbZ1P
# xFzl+koIfUTeftmN7R0rbhBV9K/9g7HDnYQJowuVbk+EdPdkg01oKZGBwcJMKU4r
# MLYU6vTdgFzbM85bpshV1eWg+YExVoT62Feo+YA0HDRiydxo6RWCCMNvk7lWo6n3
# wySUekmgkjqmTnMCXHz860LsW62t21g1QLrKRfMwA8W5iRYaDH9bsDSK0pbxbNjP
# A7dsCGmvDOei4ZmZGLDaTyl6fzQHOrN3I+9vNPFCwwIDAQABo4IBNjCCATIwHQYD
# VR0OBBYEFABExnjzSPCkrc/qq5VZQQnRzfSFMB8GA1UdIwQYMBaAFJ+nFV0AXmJd
# g/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGlt
# ZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggIBAK1OHQRCfXqQpDIJ5WT1
# VzXSbovQTAtGjcBNGi4/th3aFZ4QHZjhkXgIkp72p9dYYkrNXu0xSboMCwEpgf+d
# P7zJsjy4mIcad+dWLpKHuAWOdOl+HWPVP3Qf+4t6gWOk6f/56gKgmaitbkZvZ7OV
# OWjkjSQ0C5vG0LGpsuLO480+hvyREApCC/7j8ILUmaJQUbS4og2UqP1KwdytZ4EF
# Adfrac2DOIjBPjgmoesDTYjpyZACL0Flyx/ns44ulFiXOg8ffH/6V1LJJcCbIura
# 5Jta1C4Pzgj/RmBL8Hkvd7CpN2ITUpspfz0xbkmoIr/Ij+YAhBqaYCUc+pT15llM
# w84dCzReukKKOWT6rKjYloeLJLDDqe4+pfNTewSPdVbTRiJVJrIoS7UitHPNfctr
# yp7o6otO8r/qC7ld0qrtNPznacHog/RAz4G522vgVvHj+y+kocakr3/MG5occNdf
# kChKSyH+RINgp959AiEh9AknOgTdf4yKYwmuCvBleW1vqPUgvQdjeoKlrTcaGCLQ
# hPOp+TDcxqfcbyQHVCX5J41yI9SPvcqfa94l6cYu1PwmRQz1FSLTCg7SK5ji0mdi
# 5L5J6pq9dQ5apRhVjX0UivU8uqmZaRus7nEqOTI4egCYvGM1sqM6eQDB+37UbTSS
# 6UqrOo9ub5Kf7jsmwZAWE0ZtMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAA
# AAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUg
# QXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQAD
# ggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2
# AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpS
# g0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2r
# rPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k
# 45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSu
# eik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09
# /SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR
# 6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxC
# aC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaD
# IV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMUR
# HXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMB
# AAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQq
# p1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ
# 6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRt
# MBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBB
# MAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP
# 6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWlj
# cm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2
# Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03d
# mLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1Tk
# eFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kp
# icO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKp
# W99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrY
# UP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QB
# jloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkB
# RH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0V
# iY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq
# 0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1V
# M1izoXBm8qGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBP
# cGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0OUJDLUUzN0EtMjMz
# QzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAEBDsTEXX0qTBUvUTcB3yTQ95vp2ggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOg8d7EwIhgPMjAy
# MzA2MjEwMzA4MzNaGA8yMDIzMDYyMjAzMDgzM1owdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA6Dx3sQIBADAKAgEAAgIG0AIB/zAHAgEAAgIUzTAKAgUA6D3JMQIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFCPxKa9gEC6h3ua6lm12C7y8NePdYLD
# UVdONlcYGqAJf+s+zuqHZlCUxAJm65mAzntmpC3VWNfCXLtEG8EhF8G7Xl1AW53X
# 4JedytqK7xtBOv1fbbGSz32XLXWXo5IH+YocsWiseCZOF5+7IiEK2hAZ5DkdVlZz
# QHaUruIXSi6WMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAHAVaSNw2QVxUsAAQAAAcAwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgzZ3OHA7T
# 0wJ9Ja63trZeGIwr9nFSB8kezyPbGzJebQwwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCBa8ViiUghcwTTMr9bpewKSRhfuVg1v3IDwnHBjTg+TTzCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABwFWkjcNkFcVLAAEA
# AAHAMCIEIJYh+3Bt+GS+Lk5LkXF/cB1f62Zd+VjWeKL6xSQbxQaaMA0GCSqGSIb3
# DQEBCwUABIICABDHPS0D+RlBo3GOK6OKmnUIo2I7wN1CWEbDfdjwIPhj8GBanUlN
# YIEH6Y8RtlKviyibJqbG+0FmqH8otJQunRcdsMJIMnpD9V99ZWsxfqNuO/llWoCl
# zYNqzfw/O77JsoRURtcGSkNd9E8zsT2xR9REnv7/CJTs2tgsPQtaMjr/3x8lCjkA
# RieX+ke8fOqnzFfzZs3sWmfIATUVKpHw/UdbZN4iE7DfJFCtN6Ubai/JLSbqYuUN
# 4Ws2coV4dkoxLSSbni+3M5WNO+uc16mMynSje1we0slWrKktu6bUopMwgmzPGzRF
# 4+M98aECYnAqz7xhhvg2mxo0pFaQk6Tt6CBPQa7HbRYrW3bi8m3L8SPurn2ZCv3Q
# Jx7KSE7mcy7QUZ7Mtt8P/NdT0grGHwths4VglG7uQ6eHLQPdJK1rOSC0jfGRjb1f
# 8GrF9YSQ/eOOeZsA41dLnZgo6drE2w234qcRcWxkpw1ATVAnmhiTsZVOi7TTH0DC
# uQ6qGHfMxY8nLKzHEj8TofbytvA+uxfwdqRcAl66zt55JqiBx7aAhpaI0sOTtyMS
# 13Va6ngkxqVYm4lu+iPrb7Bs4xWLDcU67GJMNyq4yzGIH1llYnzYu3Wn+sCzlion
# U573QwOcx/y47KAYxXMGmsVvJNPPYOFaa+1ADxXcYHPEnnyiEy6Fi2Tp
# SIG # End signature block
